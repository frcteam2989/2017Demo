var struct_c_a_n_talon_1_1_motion_profile_status =
[
    [ "activePoint", "struct_c_a_n_talon_1_1_motion_profile_status.html#aef26cca61965cb71161eb2df52982c80", null ],
    [ "activePointValid", "struct_c_a_n_talon_1_1_motion_profile_status.html#ad6af70d14a610a0392186f19c52f036b", null ],
    [ "btmBufferCnt", "struct_c_a_n_talon_1_1_motion_profile_status.html#a597c83906bfbab8fe0cfbe37146a3741", null ],
    [ "hasUnderrun", "struct_c_a_n_talon_1_1_motion_profile_status.html#a5ec97fa0ef5505369b81103069fc2784", null ],
    [ "isUnderrun", "struct_c_a_n_talon_1_1_motion_profile_status.html#a2c55098ce3a4f09150ce4434e799d642", null ],
    [ "outputEnable", "struct_c_a_n_talon_1_1_motion_profile_status.html#a561e0e418de46f7ef324496d5e8dc6fc", null ],
    [ "topBufferCnt", "struct_c_a_n_talon_1_1_motion_profile_status.html#a9db6e4d8f570c2dba27269c98418ba41", null ],
    [ "topBufferRem", "struct_c_a_n_talon_1_1_motion_profile_status.html#a1042c720d455cede10218449f64946fa", null ]
];