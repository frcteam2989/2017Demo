var struct_c_a_n_talon_1_1_trajectory_point =
[
    [ "isLastPoint", "struct_c_a_n_talon_1_1_trajectory_point.html#ab726b1367a77c689128bb4ba8e51eb8c", null ],
    [ "position", "struct_c_a_n_talon_1_1_trajectory_point.html#aea7407e1a0b951cd96f4768001b245c4", null ],
    [ "profileSlotSelect", "struct_c_a_n_talon_1_1_trajectory_point.html#aa6342e0feb7ffd570dafef5f773ca250", null ],
    [ "timeDurMs", "struct_c_a_n_talon_1_1_trajectory_point.html#ab42e89d7ca0228d874ff2786dd632cb1", null ],
    [ "velocity", "struct_c_a_n_talon_1_1_trajectory_point.html#a4be656118b6bd54bc33ceb55ab1aac6b", null ],
    [ "velocityOnly", "struct_c_a_n_talon_1_1_trajectory_point.html#a6d15bfa2f22505ffc2ec14774c2705a0", null ],
    [ "zeroPos", "struct_c_a_n_talon_1_1_trajectory_point.html#ad0f0243fe8d9eaa28d0eeee1026e235e", null ]
];