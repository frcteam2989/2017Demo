var searchData=
[
  ['gadgeteeruartstatus',['GadgeteerUartStatus',['../struct_i_gadgeteer_uart_client_1_1_gadgeteer_uart_status.html',1,'IGadgeteerUartClient']]],
  ['generalstatus',['GeneralStatus',['../struct_pigeon_imu_1_1_general_status.html',1,'PigeonImu']]]
];
