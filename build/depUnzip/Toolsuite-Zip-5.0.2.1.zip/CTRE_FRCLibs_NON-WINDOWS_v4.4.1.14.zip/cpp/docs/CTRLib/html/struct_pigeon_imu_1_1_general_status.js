var struct_pigeon_imu_1_1_general_status =
[
    [ "bCalIsBooting", "struct_pigeon_imu_1_1_general_status.html#ae453f6468362fd4162f74619d214ae2e", null ],
    [ "calibrationError", "struct_pigeon_imu_1_1_general_status.html#a1f603e10aba28f68f1f50d8f6fa17d5c", null ],
    [ "currentMode", "struct_pigeon_imu_1_1_general_status.html#ac18aec7b326be9680375293dbc26bac8", null ],
    [ "description", "struct_pigeon_imu_1_1_general_status.html#a146df77af7a6c0a7f622009dfd0ce5b7", null ],
    [ "lastError", "struct_pigeon_imu_1_1_general_status.html#aebbffddb320a62582f6960c651a32793", null ],
    [ "noMotionBiasCount", "struct_pigeon_imu_1_1_general_status.html#adcd54168a45a133634f2758723a62bcc", null ],
    [ "state", "struct_pigeon_imu_1_1_general_status.html#aaa6d339448373b22af252bad8cced780", null ],
    [ "tempC", "struct_pigeon_imu_1_1_general_status.html#a3b36ff8ad580786993d4d45796091591", null ],
    [ "tempCompensationCount", "struct_pigeon_imu_1_1_general_status.html#aa415234178c327b5d7ac05b80e651c2b", null ],
    [ "upTimeSec", "struct_pigeon_imu_1_1_general_status.html#ab0aa810e7a749e93c4e0167015a1c9cc", null ]
];