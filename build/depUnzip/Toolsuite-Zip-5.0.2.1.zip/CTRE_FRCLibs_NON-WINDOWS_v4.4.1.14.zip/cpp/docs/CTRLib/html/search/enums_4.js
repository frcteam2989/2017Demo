var searchData=
[
  ['setvaluemotionprofile',['SetValueMotionProfile',['../class_c_a_n_talon.html#a3a5aa35beed1f5d9145dbd658b119b90',1,'CANTalon']]],
  ['statusframerate',['StatusFrameRate',['../class_c_a_n_talon.html#acac4ef6508d842a8fe4301284149720e',1,'CANTalon::StatusFrameRate()'],['../class_pigeon_imu.html#a655b831f9be6c185f1cc553679776b31',1,'PigeonImu::StatusFrameRate()']]]
];
